--
-- PostgreSQL database dump
--

\restrict dSLQw80s6Gj778RbXBUNLoYBu07Yng4hMkbP72yotNdoPIHltanP4Mr9RAgYRB2

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

-- Started on 2025-12-20 17:29:36 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 40976)
-- Name: badges; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.badges (
    badge_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    image_path character varying(255) NOT NULL,
    badge_type character varying(50) NOT NULL,
    tier integer DEFAULT 1,
    is_active boolean DEFAULT true,
    expires_at bigint,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()) * (1000)::numeric)
);


ALTER TABLE public.badges OWNER TO levelbot;

--
-- TOC entry 221 (class 1259 OID 40975)
-- Name: badges_badge_id_seq; Type: SEQUENCE; Schema: public; Owner: levelbot
--

CREATE SEQUENCE public.badges_badge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.badges_badge_id_seq OWNER TO levelbot;

--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 221
-- Name: badges_badge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: levelbot
--

ALTER SEQUENCE public.badges_badge_id_seq OWNED BY public.badges.badge_id;


--
-- TOC entry 217 (class 1259 OID 16403)
-- Name: items; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.items (
    item_id integer NOT NULL,
    name text NOT NULL,
    description text,
    price integer NOT NULL,
    emoji text DEFAULT '📦'::text,
    type text DEFAULT 'consumable'::text,
    hidden boolean DEFAULT false,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()))::bigint
);


ALTER TABLE public.items OWNER TO levelbot;

--
-- TOC entry 216 (class 1259 OID 16402)
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: levelbot
--

CREATE SEQUENCE public.items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.items_item_id_seq OWNER TO levelbot;

--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 216
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: levelbot
--

ALTER SEQUENCE public.items_item_id_seq OWNED BY public.items.item_id;


--
-- TOC entry 226 (class 1259 OID 41006)
-- Name: missions; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.missions (
    mission_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    mission_type character varying(50) NOT NULL,
    target_value integer NOT NULL,
    reward_badge_id integer,
    reward_coins integer DEFAULT 0,
    is_active boolean DEFAULT true,
    is_repeatable boolean DEFAULT false,
    expires_at bigint,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()) * (1000)::numeric)
);


ALTER TABLE public.missions OWNER TO levelbot;

--
-- TOC entry 225 (class 1259 OID 41005)
-- Name: missions_mission_id_seq; Type: SEQUENCE; Schema: public; Owner: levelbot
--

CREATE SEQUENCE public.missions_mission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.missions_mission_id_seq OWNER TO levelbot;

--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 225
-- Name: missions_mission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: levelbot
--

ALTER SEQUENCE public.missions_mission_id_seq OWNED BY public.missions.mission_id;


--
-- TOC entry 224 (class 1259 OID 40990)
-- Name: user_badges; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.user_badges (
    id integer NOT NULL,
    user_id character varying(30) NOT NULL,
    guild_id character varying(30) NOT NULL,
    badge_id integer NOT NULL,
    earned_at bigint DEFAULT (EXTRACT(epoch FROM now()) * (1000)::numeric),
    expires_at bigint
);


ALTER TABLE public.user_badges OWNER TO levelbot;

--
-- TOC entry 223 (class 1259 OID 40989)
-- Name: user_badges_id_seq; Type: SEQUENCE; Schema: public; Owner: levelbot
--

CREATE SEQUENCE public.user_badges_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_badges_id_seq OWNER TO levelbot;

--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 223
-- Name: user_badges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: levelbot
--

ALTER SEQUENCE public.user_badges_id_seq OWNED BY public.user_badges.id;


--
-- TOC entry 219 (class 1259 OID 16432)
-- Name: user_boosts; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.user_boosts (
    user_id text NOT NULL,
    guild_id text NOT NULL,
    boost_type text NOT NULL,
    multiplier double precision NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()))::bigint
);


ALTER TABLE public.user_boosts OWNER TO levelbot;

--
-- TOC entry 218 (class 1259 OID 16417)
-- Name: user_inventory; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.user_inventory (
    user_id text NOT NULL,
    guild_id text NOT NULL,
    item_id integer NOT NULL,
    quantity integer DEFAULT 1,
    acquired_at bigint DEFAULT (EXTRACT(epoch FROM now()))::bigint
);


ALTER TABLE public.user_inventory OWNER TO levelbot;

--
-- TOC entry 228 (class 1259 OID 41024)
-- Name: user_missions; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.user_missions (
    id integer NOT NULL,
    user_id character varying(30) NOT NULL,
    guild_id character varying(30) NOT NULL,
    mission_id integer NOT NULL,
    current_value integer DEFAULT 0,
    completed boolean DEFAULT false,
    completed_at bigint,
    started_at bigint DEFAULT (EXTRACT(epoch FROM now()) * (1000)::numeric)
);


ALTER TABLE public.user_missions OWNER TO levelbot;

--
-- TOC entry 227 (class 1259 OID 41023)
-- Name: user_missions_id_seq; Type: SEQUENCE; Schema: public; Owner: levelbot
--

CREATE SEQUENCE public.user_missions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_missions_id_seq OWNER TO levelbot;

--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 227
-- Name: user_missions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: levelbot
--

ALTER SEQUENCE public.user_missions_id_seq OWNED BY public.user_missions.id;


--
-- TOC entry 220 (class 1259 OID 16445)
-- Name: user_vips; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.user_vips (
    user_id text NOT NULL,
    guild_id text NOT NULL,
    tier text NOT NULL,
    multiplier integer NOT NULL,
    expires_at bigint NOT NULL,
    active boolean DEFAULT true,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()))::bigint,
    vip_tier text DEFAULT 'gold'::text NOT NULL
);


ALTER TABLE public.user_vips OWNER TO levelbot;

--
-- TOC entry 215 (class 1259 OID 16385)
-- Name: users; Type: TABLE; Schema: public; Owner: levelbot
--

CREATE TABLE public.users (
    user_id text NOT NULL,
    username text NOT NULL,
    guild_id text NOT NULL,
    xp integer DEFAULT 0,
    level integer DEFAULT 1,
    messages integer DEFAULT 0,
    voice_time integer DEFAULT 0,
    last_message_at bigint DEFAULT 0,
    coins integer DEFAULT 0,
    last_daily_claim bigint DEFAULT 0,
    created_at bigint DEFAULT (EXTRACT(epoch FROM now()))::bigint
);


ALTER TABLE public.users OWNER TO levelbot;

--
-- TOC entry 3319 (class 2604 OID 40979)
-- Name: badges badge_id; Type: DEFAULT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.badges ALTER COLUMN badge_id SET DEFAULT nextval('public.badges_badge_id_seq'::regclass);


--
-- TOC entry 3308 (class 2604 OID 16406)
-- Name: items item_id; Type: DEFAULT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.items ALTER COLUMN item_id SET DEFAULT nextval('public.items_item_id_seq'::regclass);


--
-- TOC entry 3325 (class 2604 OID 41009)
-- Name: missions mission_id; Type: DEFAULT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.missions ALTER COLUMN mission_id SET DEFAULT nextval('public.missions_mission_id_seq'::regclass);


--
-- TOC entry 3323 (class 2604 OID 40993)
-- Name: user_badges id; Type: DEFAULT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_badges ALTER COLUMN id SET DEFAULT nextval('public.user_badges_id_seq'::regclass);


--
-- TOC entry 3330 (class 2604 OID 41027)
-- Name: user_missions id; Type: DEFAULT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_missions ALTER COLUMN id SET DEFAULT nextval('public.user_missions_id_seq'::regclass);


--
-- TOC entry 3522 (class 0 OID 40976)
-- Dependencies: 222
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.badges (badge_id, name, description, image_path, badge_type, tier, is_active, expires_at, created_at) FROM stdin;
1	Rank 1 - Iniciante	Alcance o nível 1 a 10	badge_rank_1.png	rank	1	t	\N	1766236873456
2	Rank 2 - Aprendiz	Alcance o nível 11 a 30	badge_rank_2.png	rank	2	t	\N	1766236873461
3	Rank 3 - Experiente	Alcance o nível 31 a 60	badge_rank_3.png	rank	3	t	\N	1766236873463
4	Rank 4 - Veterano	Alcance o nível 61 a 100	badge_rank_4.png	rank	4	t	\N	1766236873465
5	Rank 5 - Elite	Alcance o nível 101 a 150	badge_rank_5.png	rank	5	t	\N	1766236873467
6	Rank 6 - Lendário	Alcance o nível 151+	badge_rank_6.png	rank	6	t	\N	1766236873469
8	Conversador	Envie 1000 mensagens	badge_mission_messages.png	mission	1	t	\N	1766236873477
9	Maratonista	Fique 100 horas em voz	badge_mission_voice.png	mission	1	t	\N	1766236873481
10	Dedicado	Colete daily por 30 dias seguidos	badge_mission_daily.png	mission	1	t	\N	1766236873485
11	Colecionador	Complete 10 missões	badge_mission_collector.png	mission	1	t	\N	1766236873488
18	Desenvolvedor	Badge exclusiva para desenvolvedores do bot	dev_badge.png	unique	1	t	\N	1766244387976
7	Natal 2025	Badge especial do evento de Natal 2025	badgexmas25.png	event	1	t	1767744000000	1766236873474
\.


--
-- TOC entry 3517 (class 0 OID 16403)
-- Dependencies: 217
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.items (item_id, name, description, price, emoji, type, hidden, created_at) FROM stdin;
2	Boost VIP Platinum	Multiplicador 3x de XP e Coins por 30 dias	0	💎	vip	t	1765758570
3	Boost VIP Ruby	Multiplicador 5x de XP e Coins por 30 dias	0	💎	vip	t	1765758570
5	XP Boost 3x	Multiplica por 3x todo XP ganho por 1 hora	150	⚡⚡	boost	t	1765758570
6	XP Boost 5x	Multiplica por 5x todo XP ganho por 1 hora	250	⚡⚡⚡	boost	t	1765758570
7	Pacote de Experiência Tier 1	Ganhe 150 XP + 10 PityCoins instantaneamente	50	📦	consumable	f	1765758570
8	Pacote de Experiência Tier 2	Ganhe 250 XP + 20 PityCoins instantaneamente	150	📦✨	consumable	f	1765758570
9	Pacote de Experiência Tier 3	Ganhe 350 XP + 40 PityCoins instantaneamente	250	📦💎	consumable	f	1765758570
4	XP Boost 2x	Multiplica por 2x todo XP ganho por 1 hora	100	⚡	boost	t	1765758570
1	Boost VIP Gold	Multiplicador 2x de XP e Coins por 30 dias	1000	⚡	vip	f	1765758570
\.


--
-- TOC entry 3526 (class 0 OID 41006)
-- Dependencies: 226
-- Data for Name: missions; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.missions (mission_id, name, description, mission_type, target_value, reward_badge_id, reward_coins, is_active, is_repeatable, expires_at, created_at) FROM stdin;
1	Envie 1000 Mensagens	Envie um total de 1000 mensagens no servidor	messages	1000	8	500	t	f	\N	1766236873505
4	Alcance o Nível 50	Alcance o nível 50 no servidor	level	50	\N	1500	t	f	\N	1766236873518
2	Fique 100 Horas em Voz	Acumule 300 horas em canais de voz	voice_time	1080000	9	1000	t	f	\N	1766236873511
\.


--
-- TOC entry 3524 (class 0 OID 40990)
-- Dependencies: 224
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.user_badges (id, user_id, guild_id, badge_id, earned_at, expires_at) FROM stdin;
8	524622388629995541	832509216895926314	1	1766241007065	\N
11	524622388629995541	832509216895926314	18	1766244497243	\N
12	524622388629995541	832509216895926314	7	1766247383630	\N
13	1020092240779022387	832509216895926314	8	1766248788710	\N
14	1020092240779022387	832509216895926314	2	1766249424639	\N
15	1020092240779022387	832509216895926314	7	1766249473766	\N
\.


--
-- TOC entry 3519 (class 0 OID 16432)
-- Dependencies: 219
-- Data for Name: user_boosts; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.user_boosts (user_id, guild_id, boost_type, multiplier, expires_at, created_at) FROM stdin;
524622388629995541	832509216895926314	vip_boost	2	1768839405430	1766247262
\.


--
-- TOC entry 3518 (class 0 OID 16417)
-- Dependencies: 218
-- Data for Name: user_inventory; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.user_inventory (user_id, guild_id, item_id, quantity, acquired_at) FROM stdin;
524622388629995541	832509216895926314	2	498	1766245531
524622388629995541	832509216895926314	3	499	1766245531
524622388629995541	832509216895926314	1	498	1766245531
\.


--
-- TOC entry 3528 (class 0 OID 41024)
-- Dependencies: 228
-- Data for Name: user_missions; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.user_missions (id, user_id, guild_id, mission_id, current_value, completed, completed_at, started_at) FROM stdin;
3	1335375360099090462	832509216895926314	1	5	f	\N	1766238237286
4	1335375360099090462	832509216895926314	4	2	f	\N	1766238237294
58	1376642803081281596	832509216895926314	4	1	f	\N	1766247702532
17	524622388629995541	832509216895926314	1	42	f	\N	1766243103425
20	568959069348429824	832509216895926314	4	10	f	\N	1766243410023
18	524622388629995541	832509216895926314	4	4	f	\N	1766243103431
5	598644577548763166	832509216895926314	1	213	f	\N	1766238904652
6	598644577548763166	832509216895926314	4	7	f	\N	1766238904657
11	411199888437805057	832509216895926314	1	390	f	\N	1766242000692
61	1158171341053243422	832509216895926314	1	31	f	\N	1766247848894
62	1158171341053243422	832509216895926314	4	3	f	\N	1766247848902
12	411199888437805057	832509216895926314	4	10	f	\N	1766242000699
39	1442128071242027169	832509216895926314	2	211	f	\N	1766245706686
23	730812142214709270	832509216895926314	1	60	f	\N	1766244005689
1	1057676828279578655	832509216895926314	1	176	f	\N	1766237999382
2	1057676828279578655	832509216895926314	4	7	f	\N	1766237999386
35	805842951035945011	832509216895926314	1	62	f	\N	1766245175374
37	805842951035945011	832509216895926314	4	4	f	\N	1766245175381
49	1320228052671922247	832509216895926314	1	1	f	\N	1766246608982
69	1448598211416690733	832509216895926314	1	330	f	\N	1766250443369
70	1448598211416690733	832509216895926314	4	9	f	\N	1766250443373
67	905871228236075058	832509216895926314	1	12	f	\N	1766249434442
68	905871228236075058	832509216895926314	4	2	f	\N	1766249434448
51	1320228052671922247	832509216895926314	4	1	f	\N	1766246608993
13	426581463706763275	832509216895926314	1	11	f	\N	1766242325398
71	982444303265722388	832509216895926314	1	32	f	\N	1766251228714
72	982444303265722388	832509216895926314	4	3	f	\N	1766251228718
9	1378155254192803980	832509216895926314	1	80	f	\N	1766241998094
10	1378155254192803980	832509216895926314	4	5	f	\N	1766241998098
73	701967682169208873	832509216895926314	1	74	f	\N	1766251316743
14	426581463706763275	832509216895926314	4	2	f	\N	1766242325404
74	701967682169208873	832509216895926314	4	5	f	\N	1766251316746
59	1435520697685245983	832509216895926314	1	16	f	\N	1766247767409
60	1435520697685245983	832509216895926314	4	2	f	\N	1766247767413
7	778824717674348564	832509216895926314	1	163	f	\N	1766241034493
8	778824717674348564	832509216895926314	4	6	f	\N	1766241034496
64	1020092240779022387	832509216895926314	4	16	f	\N	1766248724774
31	1447027290742460576	832509216895926314	1	9	f	\N	1766244496752
33	1447027290742460576	832509216895926314	4	2	f	\N	1766244496759
24	730812142214709270	832509216895926314	4	4	f	\N	1766244005693
63	1020092240779022387	832509216895926314	1	1199	t	1766248788699	1766248724770
21	1444423854603898973	832509216895926314	1	739	f	\N	1766243436166
22	1444423854603898973	832509216895926314	4	14	f	\N	1766243436172
15	1285070921790394481	832509216895926314	1	12	f	\N	1766242330165
16	1285070921790394481	832509216895926314	4	2	f	\N	1766242330171
65	1394490878378377257	832509216895926314	1	154	f	\N	1766248876029
66	1394490878378377257	832509216895926314	4	8	f	\N	1766248876037
19	568959069348429824	832509216895926314	1	399	f	\N	1766243410015
57	1376642803081281596	832509216895926314	1	1	f	\N	1766247702527
\.


--
-- TOC entry 3520 (class 0 OID 16445)
-- Dependencies: 220
-- Data for Name: user_vips; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.user_vips (user_id, guild_id, tier, multiplier, expires_at, active, created_at, vip_tier) FROM stdin;
524622388629995541	832509216895926314	gold	2	1768839405430	t	1766247405430	gold
\.


--
-- TOC entry 3515 (class 0 OID 16385)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: levelbot
--

COPY public.users (user_id, username, guild_id, xp, level, messages, voice_time, last_message_at, coins, last_daily_claim, created_at) FROM stdin;
1029765354668429382	eubelli	832509216895926314	722	3	36	0	1765939206671	11	1765770092099	1765757659
598644577548763166	lh.uchiha	832509216895926314	4299	7	213	0	1766246865328	47	1765877853606	1765755810
1438478764387467336	fanumero1docarlinhosmaia	832509216895926314	107	2	5	0	1765764224929	1	0	1765763964
1433456436574425201	fernandohaddad	832509216895926314	46	1	2	148	1765814603270	0	0	1765813851
1449624151936471183	mgbwwjbu	832509216895926314	15	1	1	0	1765812653416	0	0	1765812653
811090100082966548	mymelodyzzzzzzzzz	832509216895926314	43	1	2	0	1765776864339	0	0	1765776788
1335375360099090462	feeh03729	832509216895926314	139	2	5	2124	1766238237268	1	0	1765768692
1449908618123280536	calmafio	832509216895926314	0	1	0	0	0	0	0	1765756085
833755886597177465	casswood_777	832509216895926314	235	2	11	0	1766076155364	2	0	1765819098
1186068525522092107	thallys_______	832509216895926314	66	1	4	0	1765868487598	0	0	1765760957
1169064050689318923	rizzguw.1	832509216895926314	0	1	0	0	0	0	0	1765756983
1086800149810008168	kdbr14.	832509216895926314	39	1	1	1204	1765892742497	0	0	1765758306
1425701203022450779	coffengz7	832509216895926314	59	1	3	0	1765943568959	0	0	1765772371
730812142214709270	ktarinna	832509216895926314	1500	4	60	17667	1766247564760	19	1765915345243	1765760570
1449865139498123285	ibeliveinunicorns1	832509216895926314	23	1	1	0	1765772915238	0	0	1765772915
1344635625252585472	kaizer08948	832509216895926314	167	2	8	1007	1766167222004	1	0	1765792641
1435520697685245983	yurialvz_	832509216895926314	346	2	16	0	1766248256443	3	0	1765758649
1394490878378377257	kaduw_w	832509216895926314	5453	8	154	147239	1766248876020	54	0	1765758882
297465330874318848	beatz6982	832509216895926314	28	1	0	1769	0	0	0	1765818642
524622388629995541	lyepedro	832509216895926314	1369	4	42	16499	1766250005477	4	1766237035382	1765756891
987523123488362566	lyra.msr	832509216895926314	713	3	30	9603	1765941698995	7	0	1765759154
1449913112651366541	shiizukesa.	832509216895926314	23	1	1	0	1765757462758	0	0	1765757463
805842951035945011	kyzuke__	832509216895926314	1226	4	62	0	1766250424842	12	0	1765798543
723968384890437782	gustakkp	832509216895926314	219	2	11	0	1766091984162	2	0	1765818022
1189502038271340626	ugaugaedu	832509216895926314	39	1	2	0	1765762449565	0	0	1765760484
778824717674348564	nomecriativo_	832509216895926314	3205	6	163	0	1766250553265	32	0	1765755534
1444423854603898973	utgem_kodak	832509216895926314	18261	14	739	210253	1766250660034	80	1766174961371	1765755824
1351676809019785338	rodrigo8642_	832509216895926314	365	2	17	0	1766000367998	0	0	1765763306
411916947773587456	Jockie Music	832509216895926314	224	2	0	14151	0	2	0	1765809834
872568405159477278	gury.r.	832509216895926314	203	2	10	0	1765860978981	2	0	1765767340
1242296854939697184	shinaider1	832509216895926314	201	2	10	0	1766232430651	2	0	1765757108
1340017133324599346	ravonsodecria	832509216895926314	134	2	6	495	1765919383075	1	0	1765918679
951613309583511562	davioscar	832509216895926314	270	2	8	7039	1766084355023	2	0	1765815576
1246983330126233645	foxpink_222	832509216895926314	574	3	29	0	1766192562726	5	0	1765770238
389245578711924746	.unitycreed	832509216895926314	20	1	1	0	1765911191914	0	0	1765911192
1316786844523954276	kauan22110222	832509216895926314	73	1	1	2946	1765825690421	0	0	1765825690
1360778320320532501	sanag1__33400	832509216895926314	949	4	48	0	1766009863107	9	0	1765756934
876557484112904202	joaozinnn123	832509216895926314	740	3	20	19907	1766143550167	7	0	1765757787
1449975595071967353	lilbomb0815	832509216895926314	21	1	1	0	1765772344811	0	0	1765772345
832776723526713365	the_kingred	832509216895926314	15	1	1	0	1765769125428	0	0	1765769125
1406761793405059079	eomv641_31858	832509216895926314	41	1	2	123	1765801873872	0	0	1765758790
1189348531727773759	artkiiko123	832509216895926314	239	2	12	0	1765843373242	2	0	1765774599
1053321146692538439	yang687	832509216895926314	166	2	8	0	1766074277676	1	0	1765774716
1447379613784342670	comedorade_ratos	832509216895926314	144	2	8	0	1765814712735	1	0	1765785051
733065878249144531	miku._u	832509216895926314	8231	10	354	66327	1766029392289	82	0	1765756043
813424892124069928	saitozin_777	832509216895926314	62	1	3	0	1766190477604	0	0	1765762528
1447027290742460576	ph.segjesus	832509216895926314	224	2	9	2214	1766244925939	2	0	1765759137
1247335822223474764	guilherme150662	832509216895926314	54	1	1	2238	1766114101084	0	0	1765762997
1439316513449443711	luvadedreiro	832509216895926314	253	2	12	0	1766066235316	2	0	1765764323
568959069348429824	_shineexz	832509216895926314	8751	10	399	42717	1766245499135	98	1766173184787	1765756361
1435832982689550397	gogobebe0199	832509216895926314	3666	7	177	9147	1766208476643	36	0	1765756741
1432921023275204703	ovadas019	832509216895926314	140	2	7	0	1765778427832	1	0	1765777547
402483811948036107	.saka04	832509216895926314	16629	13	636	242449	1766217894771	47	1766167271541	1765755340
1057676828279578655	h4rd_zip	832509216895926314	3601	7	176	60	1766246516109	36	0	1765755674
1022267838188241008	justciell	832509216895926314	99	1	4	0	1765785466628	0	0	1765784062
1442982222721192046	kadu054935	832509216895926314	0	1	0	0	0	0	0	1765778517
839755401049407508	m0l8	832509216895926314	3058	6	111	50241	1766180619345	30	0	1765764808
1439358892554453123	liriliritralala	832509216895926314	117	2	6	0	1765900409461	1	0	1765765016
1440135564367237162	itoshisae00506	832509216895926314	237	2	12	0	1765930859442	2	0	1765924238
1225476346613071933	felipe._.e	832509216895926314	1664	5	53	36811	1766232374994	16	0	1765936370
1416297656010936390	h4sio4	832509216895926314	206	2	8	2293	1765829650849	2	0	1765827944
833452826079526932	killerbbr	832509216895926314	19	1	1	0	1766000039890	0	0	1766000040
936380829335191623	yuyu_zt	832509216895926314	54	1	3	0	1766075881712	0	0	1766075742
360177747152207874	dohkojb	832509216895926314	1	1	0	94	0	0	0	1765849410
696068862592155658	meajudempeloamordedeus	832509216895926314	21	1	1	0	1766074312664	0	0	1766074313
325274548612104193	datatag	832509216895926314	65	1	0	3904	0	0	0	1766213737
542050862391099413	amethsta	832509216895926314	196	2	10	0	1766074340217	1	0	1765850721
863064928754335794	leeh_xxz	832509216895926314	96	1	4	862	1766066533890	0	0	1766035050
1439656736737722499	fan_numero1dojosefernamdo	832509216895926314	391	2	18	0	1766005102825	1	0	1765899644
1032460957970079775	eu_eloo_612	832509216895926314	38	1	2	0	1765944331976	0	0	1765944271
1320228052671922247	karynxz	832509216895926314	22	1	1	0	1766246608946	0	0	1766246609
700116961459437640	kaynan_157	832509216895926314	8	1	0	504	0	0	0	1765828590
926176191147298859	samanbaia1222	832509216895926314	20	1	1	0	1765831596090	0	0	1765831596
742095018361356451	vexcyn_ox	832509216895926314	167	2	9	0	1766074371568	1	0	1766071875
1280292871328763977	alcinha1	832509216895926314	16	1	1	0	1765942005151	0	0	1765942005
1444775168215093480	mafisxz	832509216895926314	18	1	1	0	1766042069235	0	0	1766042069
905871228236075058	ah_wn	832509216895926314	236	2	12	0	1766250487975	2	0	1766114204
1334666313309753508	octomnius	832509216895926314	20	1	1	0	1766060785225	0	0	1766060785
1409542071869505586	guibs0462	832509216895926314	19	1	1	0	1765937507049	0	0	1765937507
1409725151603593331	zeupola	832509216895926314	476	3	23	0	1766090606759	4	0	1766001375
1439320599230021913	gabiiurls	832509216895926314	97	1	5	0	1765989470107	0	0	1765899823
1421560167631159321	8075580447	832509216895926314	17	1	1	0	1765834508014	0	0	1765834508
1102555734106984539	cdzzz17	832509216895926314	197	2	9	0	1766155665234	1	0	1765828318
1201195870419431475	lczin_chef17	832509216895926314	124	2	6	0	1766097860158	1	0	1766011628
1376566469869043763	da2314aasda2	832509216895926314	111	2	5	215	1766032766532	1	0	1766031894
1358556169211478229	titankatowice2014	832509216895926314	884	3	31	15407	1766079417952	8	0	1766075598
1373475214846853145	guizeira_.fxp7_24580	832509216895926314	857	3	40	2394	1765869354316	8	0	1765865484
1449889622833234051	kingbaldwin_1v	832509216895926314	147	2	8	0	1766207287899	1	0	1766033014
1212898993890140162	soy_anya.	832509216895926314	169	2	9	0	1766020380590	1	0	1766018189
1119556679894319154	blulimx	832509216895926314	0	1	0	0	0	5	1765864157881	1765864158
1188055953514446888	kimdimkim	832509216895926314	335	2	17	327	1766171546035	3	0	1766027179
762824483484073996	gabi_zinha0987	832509216895926314	15	1	1	0	1765999883185	0	0	1765999883
1448598211416690733	gabzx0141109_69226	832509216895926314	7896	9	330	76991	1766251117287	78	0	1765757436
1267129002183753798	konosuba0699_82156	832509216895926314	87	1	2	2698	1766104160574	0	0	1766103285
1271103186161238161	lodrih.	832509216895926314	458	3	22	0	1766199961597	7	1766199916558	1765859586
982444303265722388	ninguem05035	832509216895926314	790	3	32	8765	1766251228694	7	0	1765901732
701967682169208873	bilmeck	832509216895926314	1869	5	74	23666	1766251316723	18	0	1765942114
1441520507328659570	kassadin.aura	832509216895926314	3	1	0	189	0	0	0	1766012566
1436168000922321022	rodrigo_88448844	832509216895926314	2	1	0	139	0	0	0	1766026247
1138553242834444329	kiwi_chan00	832509216895926314	242	2	12	0	1766018180511	2	0	1766017178
1088623739828178985	davizim46478	832509216895926314	1089	4	44	10839	1766187319530	10	0	1765769044
889186841331388488	yyrita	832509216895926314	89	1	4	0	1766007531749	0	0	1766006039
1201616829253173291	barbosa014	832509216895926314	468	3	16	7104	1765824405558	4	0	1765822283
1450986460059668550	.brenno4lifee	832509216895926314	16	1	1	0	1766017217497	0	0	1766017217
1345804215028683003	norasfucknerd	832509216895926314	16	1	1	0	1765948610095	0	0	1765948610
1450641484381425813	l4fe_02	832509216895926314	698	3	14	24289	1766114605355	6	0	1765988548
1092230219311620137	wl23	832509216895926314	78	1	4	167	1766030637879	0	0	1765869606
710204313817055322	andre._.677	832509216895926314	117	2	4	2004	1766033075837	1	0	1766032796
1192894244990492764	hannikkj_	832509216895926314	24	1	1	0	1766190848725	0	0	1766190849
1129475192452812850	luannaxzz	832509216895926314	20137	15	856	180783	1766042856997	701	1766040755800	1765755304
1436445403024330792	itachi_sama0	832509216895926314	236	2	11	1087	1766043758713	2	0	1765863013
1432616448936775803	narutoman109	832509216895926314	171	2	8	0	1766033318067	1	0	1766032677
865032128856981524	guimaarts	832509216895926314	452	3	22	0	1766163248730	4	0	1765823039
1318338401866354769	tarcisiosin2_28228	832509216895926314	97	1	4	1224	1766163316202	0	0	1766111285
1439323865737200040	roberto04843	832509216895926314	48	1	2	0	1765900128060	0	0	1765900042
1387908937986084865	natasha_rodrigues	832509216895926314	25	1	1	0	1766096907009	0	0	1766096907
1439360403548143616	fadavirginia	832509216895926314	59	1	3	0	1765900306237	0	0	1765900173
1442196045579681795	ayu_desu.	832509216895926314	320	2	16	0	1766177800880	3	0	1766176283
1451444110853541908	satorugojo02118	832509216895926314	124	2	6	0	1766154965652	1	0	1766122495
748318940949643276	nickinhs52	832509216895926314	41	1	2	0	1766114422600	0	0	1766114257
1448516085631553749	neon.ys	832509216895926314	15	1	1	0	1766114629408	0	0	1766114629
1376642803081281596	bruno.jol_33530	832509216895926314	24	1	1	0	1766247702497	0	0	1766247702
1314745083383517237	s4t1ra_57612	832509216895926314	3448	6	152	25598	1766200056739	34	0	1766034271
1158171341053243422	ogoidgameryt_91015	832509216895926314	593	3	31	0	1766247848886	5	0	1766182601
426581463706763275	lisopk	832509216895926314	201	2	11	0	1766248225834	2	0	1765833792
1447778737142759559	o_quimico	832509216895926314	4481	7	218	7374	1766201593104	44	0	1765831188
1202734218002702347	fariasb4	832509216895926314	40	1	2	0	1766182555192	0	0	1766182461
1285070921790394481	zstreest_10759	832509216895926314	233	2	12	0	1766248875618	2	0	1766242330
1442128071242027169	kalleb_roblox_user	832509216895926314	3	1	0	211	0	0	0	1766245707
1144724424055062649	noobvini	832509216895926314	88	1	1	4182	1766217247467	0	0	1766217247
1378155254192803980	bskkj	832509216895926314	2123	5	80	30876	1766242571026	21	0	1766116327
1374199019265593454	zk03638	832509216895926314	49	1	2	0	1766123874883	0	0	1766120481
411199888437805057	surigato1	832509216895926314	8535	10	390	44672	1766250957883	100	1766114052500	1765764077
1020092240779022387	yurimorozov_	832509216895926314	25567	16	1219	67617	1766251557394	657	1766230740126	1765755295
\.


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 221
-- Name: badges_badge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: levelbot
--

SELECT pg_catalog.setval('public.badges_badge_id_seq', 23, true);


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 216
-- Name: items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: levelbot
--

SELECT pg_catalog.setval('public.items_item_id_seq', 9, true);


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 225
-- Name: missions_mission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: levelbot
--

SELECT pg_catalog.setval('public.missions_mission_id_seq', 8, true);


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 223
-- Name: user_badges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: levelbot
--

SELECT pg_catalog.setval('public.user_badges_id_seq', 15, true);


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 227
-- Name: user_missions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: levelbot
--

SELECT pg_catalog.setval('public.user_missions_id_seq', 74, true);


--
-- TOC entry 3352 (class 2606 OID 40988)
-- Name: badges badges_name_key; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_name_key UNIQUE (name);


--
-- TOC entry 3354 (class 2606 OID 40986)
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (badge_id);


--
-- TOC entry 3339 (class 2606 OID 16416)
-- Name: items items_name_key; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_name_key UNIQUE (name);


--
-- TOC entry 3341 (class 2606 OID 16414)
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (item_id);


--
-- TOC entry 3361 (class 2606 OID 41017)
-- Name: missions missions_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.missions
    ADD CONSTRAINT missions_pkey PRIMARY KEY (mission_id);


--
-- TOC entry 3357 (class 2606 OID 40996)
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- TOC entry 3359 (class 2606 OID 40998)
-- Name: user_badges user_badges_user_id_guild_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_guild_id_badge_id_key UNIQUE (user_id, guild_id, badge_id);


--
-- TOC entry 3347 (class 2606 OID 16439)
-- Name: user_boosts user_boosts_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_boosts
    ADD CONSTRAINT user_boosts_pkey PRIMARY KEY (user_id, guild_id, boost_type);


--
-- TOC entry 3344 (class 2606 OID 16425)
-- Name: user_inventory user_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_inventory
    ADD CONSTRAINT user_inventory_pkey PRIMARY KEY (user_id, guild_id, item_id);


--
-- TOC entry 3365 (class 2606 OID 41032)
-- Name: user_missions user_missions_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_missions
    ADD CONSTRAINT user_missions_pkey PRIMARY KEY (id);


--
-- TOC entry 3367 (class 2606 OID 41034)
-- Name: user_missions user_missions_user_id_guild_id_mission_id_key; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_missions
    ADD CONSTRAINT user_missions_user_id_guild_id_mission_id_key UNIQUE (user_id, guild_id, mission_id);


--
-- TOC entry 3350 (class 2606 OID 16453)
-- Name: user_vips user_vips_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_vips
    ADD CONSTRAINT user_vips_pkey PRIMARY KEY (user_id, guild_id, tier);


--
-- TOC entry 3337 (class 2606 OID 16399)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id, guild_id);


--
-- TOC entry 3345 (class 1259 OID 16440)
-- Name: idx_boosts_expiry; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_boosts_expiry ON public.user_boosts USING btree (user_id, guild_id, expires_at);


--
-- TOC entry 3334 (class 1259 OID 16400)
-- Name: idx_guild_xp; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_guild_xp ON public.users USING btree (guild_id, xp DESC);


--
-- TOC entry 3342 (class 1259 OID 16431)
-- Name: idx_inventory_user; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_inventory_user ON public.user_inventory USING btree (user_id, guild_id);


--
-- TOC entry 3355 (class 1259 OID 41004)
-- Name: idx_user_badges_user; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_user_badges_user ON public.user_badges USING btree (user_id, guild_id);


--
-- TOC entry 3335 (class 1259 OID 16401)
-- Name: idx_user_guild; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_user_guild ON public.users USING btree (user_id, guild_id);


--
-- TOC entry 3362 (class 1259 OID 41041)
-- Name: idx_user_missions_mission; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_user_missions_mission ON public.user_missions USING btree (mission_id);


--
-- TOC entry 3363 (class 1259 OID 41040)
-- Name: idx_user_missions_user; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_user_missions_user ON public.user_missions USING btree (user_id, guild_id);


--
-- TOC entry 3348 (class 1259 OID 16454)
-- Name: idx_vips_expiry; Type: INDEX; Schema: public; Owner: levelbot
--

CREATE INDEX idx_vips_expiry ON public.user_vips USING btree (user_id, guild_id, expires_at);


--
-- TOC entry 3370 (class 2606 OID 41018)
-- Name: missions missions_reward_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.missions
    ADD CONSTRAINT missions_reward_badge_id_fkey FOREIGN KEY (reward_badge_id) REFERENCES public.badges(badge_id) ON DELETE SET NULL;


--
-- TOC entry 3369 (class 2606 OID 40999)
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(badge_id) ON DELETE CASCADE;


--
-- TOC entry 3368 (class 2606 OID 16426)
-- Name: user_inventory user_inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_inventory
    ADD CONSTRAINT user_inventory_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.items(item_id);


--
-- TOC entry 3371 (class 2606 OID 41035)
-- Name: user_missions user_missions_mission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: levelbot
--

ALTER TABLE ONLY public.user_missions
    ADD CONSTRAINT user_missions_mission_id_fkey FOREIGN KEY (mission_id) REFERENCES public.missions(mission_id) ON DELETE CASCADE;


-- Completed on 2025-12-20 17:29:36 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict dSLQw80s6Gj778RbXBUNLoYBu07Yng4hMkbP72yotNdoPIHltanP4Mr9RAgYRB2

